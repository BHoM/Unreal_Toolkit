// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "GameFramework/GameMode.h"
#include "Unreal_ToolkitGameMode.generated.h"

/**
 * 
 */
UCLASS()
class UNREAL_TOOLKIT_API AUnreal_ToolkitGameMode : public AGameMode
{
	GENERATED_BODY()
	
	
	
	
};
